<?php
/**
 * Plugin Name: Форматирование полей в формах WordPress
 * Description: Добавляет поле ввода телефонного номера с флагами и кодами стран для форм Elementor и WooCommerce. Устанавливает Молдову по умолчанию и применяет маску ввода для российских номеров. Добавляет маску ввода для электронной почты.
 * Version: 1.24
 * Author: @maincoder_ru
 * Text Domain: intl-tel-input-elementor
 */

// Подключение необходимых стилей и скриптов
function enqueue_intl_tel_input_assets() {
    wp_enqueue_style('intl-tel-input-css', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css');
    wp_enqueue_script('intl-tel-input-js', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', array('jquery'), '17.0.8', true);
    wp_enqueue_script('intl-tel-input-utils-js', 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js', array('intl-tel-input-js'), '17.0.8', true);
    wp_enqueue_script('jquery-mask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js', array('jquery'), '1.14.16', true);
    wp_enqueue_script('jquery-inputmask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.7-beta.29/jquery.inputmask.min.js', array('jquery'), '5.0.7-beta.29', true);
}
add_action('wp_enqueue_scripts', 'enqueue_intl_tel_input_assets');

// Добавление стилей для всплывающей подсказки
function add_custom_styles() {
    ?>
    <style>
        .error-tooltip {
            display: none;
            position: absolute;
            background-color: #f44336;
            color: #fff;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
            z-index: 1000;
        }

        .error-tooltip::after {
            content: '';
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #f44336 transparent transparent transparent;
        }
    </style>
    <?php
}
add_action('wp_head', 'add_custom_styles');

// Инициализация intl-tel-input для полей Elementor и WooCommerce
function init_intl_tel_input() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            function initializeIntlTelInput(input) {
                var iti = window.intlTelInput(input, {
                    initialCountry: "md", // Устанавливаем Молдову по умолчанию
                    separateDialCode: true, // Отображение кода страны отдельно
                    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
                });

                function formatPhoneNumber() {
                    var value = input.value.replace(/\D/g, ''); // Удаление всех нецифровых символов
                    input.value = value;
                }

                // Обработка ввода и вставки текста
                $(input).on('input paste', function() {
                    setTimeout(formatPhoneNumber, 100);
                });

                // Удаление скобок и дефисов перед отправкой формы и добавление кода страны
                $(input.form).on('submit', function() {
                    var fullNumber = iti.getNumber();
                    input.value = fullNumber; // Сохраняем номер телефона в международном формате
                });
            }

            // Показ всплывающей подсказки
            function showErrorTooltip(input, message) {
                var tooltip = $('<div class="error-tooltip"></div>').text(message);
                $('body').append(tooltip);
                var offset = $(input).offset();
                tooltip.css({
                    top: offset.top - tooltip.outerHeight() - 10,
                    left: offset.left + ($(input).outerWidth() - tooltip.outerWidth()) / 2
                }).fadeIn();

                setTimeout(function() {
                    tooltip.fadeOut(function() {
                        tooltip.remove();
                    });
                }, 5000);
            }

            // Функция для инициализации полей
            function initPhoneAndEmailFields(container) {
                var phoneInputSelectors = container.find('input[type="tel"], #billing_phone, #shipping_phone, #account_phone'); // Массив селекторов полей ввода телефона
                phoneInputSelectors.each(function() {
                    initializeIntlTelInput(this);
                });

                // Применение маски ввода для поля электронной почты
                container.find('input[type="email"]').inputmask({
                    alias: "email",
                    placeholder: "mail@domain.com",
                    clearIncomplete: true,
                    clearMaskOnLostFocus: true
                });

                // Очистка поля электронной почты при загрузке страницы
                function clearEmailField() {
                    container.find('#billing_email').val('');
                    container.find('#billing_email').removeAttr('autocomplete');
                    container.find('form.elementor-form input[type="email"]').each(function() {
                        $(this).val('');
                        $(this).removeAttr('autocomplete');
                    });
                }

                clearEmailField();

                // Очистка поля электронной почты, если оно не соответствует маске при потере фокуса
                container.find('input[type="email"]').on('blur', function() {
                    var email = $(this).val();
                    var regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
                    if (!regex.test(email)) {
                        showErrorTooltip(this, 'Ați introdus date nevalide. Încearcă din nou.');
                        $(this).val('');
                    }
                });
            }

            // Инициализация на всех полях ввода при загрузке страницы
            initPhoneAndEmailFields($(document));

            // Инициализация на полях ввода в попапах при их открытии
            $(document).on('elementor/popup/show', function(event, id, instance) {
                initPhoneAndEmailFields(instance.$element);
            });
        });
    </script>
    <?php
}
add_action('wp_footer', 'init_intl_tel_input', 100);
?>
